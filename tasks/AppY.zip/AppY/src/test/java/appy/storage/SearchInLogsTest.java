package appy.storage;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.junit.Test;
import static org.junit.Assert.assertTrue;

public class SearchInLogsTest {

    @Test
    public void test() {
        List<String> keywords = new ArrayList<>();
        keywords.add("TransportException");
        keywords.add("Exception");
        ConcurrentHashMap<String, Integer> results = SearchInLogs.searchInAll("cloud-log-storage", "exceptions",
                                                                              keywords);
        assertTrue(results.size() == 2);
        assertTrue(results.get("TransportException") == 2);
        assertTrue(results.get("Exception") == 783);
    }
}
