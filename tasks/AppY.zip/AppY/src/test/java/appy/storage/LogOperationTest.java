package appy.storage;

import java.util.List;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class LogOperationTest {

    @Test
    public void test() {
        List<String> logs = LogOperations.getAllLogs("cloud-log-storage", "exceptions");
        assertEquals(11, logs.size());
    }
}
