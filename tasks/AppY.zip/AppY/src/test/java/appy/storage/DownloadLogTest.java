package appy.storage;

import java.io.File;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertTrue;

public class DownloadLogTest {
    private List<String> logs;
    private String bucket = "cloud-log-storage";

    @Before
    public void setUp() {
        logs = LogOperations.getAllLogs(bucket, "exceptions");
    }

    @Test
    public void test() {

        logs.forEach(log -> assertTrue(S3FileHandler.download(bucket, log)));
        for (String log : logs) {
            File file = new File(log);
            assertTrue(file.exists());
        }
    }

    @After
    public void cleanUp() {
        for (String log : logs) {
            File file = new File(log);
            file.delete();
        }
    }
}
