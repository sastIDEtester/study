package appy.storage;

import java.util.ArrayList;
import java.util.List;

import appy.utils.ClientUtils;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.S3ObjectSummary;

public class LogOperations {

    /**
     * Retrieve all logs containing the given keyword from the specified bucket.
     *
     * @param bucketName the bucketname.
     * @param keyword    the keyword to search for.
     * @return a list of Logs containing the given keyword.
     */
    public static List<String> getAllLogs(String bucketName, String keyword) {
        List<String> logs = new ArrayList<String>();
        AmazonS3 s3 = ClientUtils.getS3();
        ObjectListing result = s3.listObjects(bucketName);
        List<S3ObjectSummary> objects = result.getObjectSummaries();
        for (S3ObjectSummary os : objects) {
            if (os.getKey().contains(keyword))
                logs.add(os.getKey());
        }
        return logs;
    }

    /**
     * Lists and prints all logs from the given bucketname and the given keyword into the console.
     *
     * @param bucketName the bucket name
     * @param keyword    the keyword to search for.
     */
    public static void listAllLogsAndPrint(String bucketName, String keyword) {
        System.out.println(String.format("Objects with keyword %s:", keyword));
        List<String> logs = getAllLogs(bucketName, keyword);
        print(logs);
    }

    public static void print(List<String> logs) {
        logs.forEach(s -> System.out.println(s));
    }
}
