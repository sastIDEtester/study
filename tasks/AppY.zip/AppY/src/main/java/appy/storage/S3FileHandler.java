package appy.storage;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import appy.utils.ClientUtils;
import org.apache.http.HttpStatus;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;

public class S3FileHandler {

    /**
     * Download the file with the given file name from the bucket. A file with the same name will be created locally.
     *
     * @param bucketName the name of the bucket to download from.
     * @param fileName   the name of the file to download.
     * @return true if the operation was successfull, false if not
     */
    public static boolean download(String bucketName, String fileName) {
        System.out.format("Downloading %s from S3 bucket %s...\n", bucketName, fileName);
        final AmazonS3 s3 = ClientUtils.getS3();
        try {
            S3Object o = s3.getObject(bucketName, fileName);
            try (S3ObjectInputStream s3is = o.getObjectContent()) {
                FileOutputStream fos = new FileOutputStream(new File(fileName));
                byte[] read_buf = new byte[1024];
                int read_len = 0;
                while ((read_len = s3is.read(read_buf)) > 0) {
                    fos.write(read_buf, 0, read_len);
                }
            }
        } catch (AmazonServiceException e) {
            if (e.getStatusCode() == HttpStatus.SC_FORBIDDEN) {
                String errorMsg = String.format("Access denied to bucket: %s");
                System.err.println(errorMsg);
                throw new RuntimeException(e);

            } else if (e.getStatusCode() == HttpStatus.SC_NOT_FOUND) {
                String errorMsg = String.format("Key:%s doesn't exist", fileName);
                System.err.println(errorMsg);
                throw new RuntimeException(e);
            }
            String errorMsg = "Serialized data could not be read from S3:" + e.getMessage();
            System.err.println(errorMsg);
            throw new RuntimeException(e);

        } catch (IOException e) {
            throw new RuntimeException("Failed to download file.");
        }

        System.out.println("Done!");
        return true;
    }

    /**
     * Deletes the log with the given file name from the specified bucket.
     *
     * @param bucketName the name of the bucket to delete from.
     * @param fileName   the name of the file to be deleted.
     * @return
     */
    public static boolean removeLog(String bucketName, String fileName) {
        System.out.format("Removing %s from S3 bucket %s...\n", bucketName, fileName);
        try {
            final AmazonS3 s3 = ClientUtils.getS3();
            s3.deleteObject(bucketName, fileName);
        } catch (AmazonServiceException e) {
            if (e.getStatusCode() == HttpStatus.SC_FORBIDDEN) {
                String errorMsg = String.format("Access denied to bucket: %s");
                System.err.println(errorMsg);
                throw new RuntimeException(e);

            } else if (e.getStatusCode() == HttpStatus.SC_NOT_FOUND) {
                String errorMsg = String.format("Key:%s doesn't exist", fileName);
                System.err.println(errorMsg);
                throw new RuntimeException(e);
            }
            String errorMsg = "Serialized data could not be read from S3:" + e.getMessage();
            System.err.println(errorMsg);
            throw new RuntimeException(e);
        }
        System.out.println("Done!");
        return true;
    }

}
