package appy.storage;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.io.FileUtils;

public class SearchInLogs {
    private static ConcurrentHashMap<String, Integer> results;

    /**
     * Search for the keyword in the given file contents.
     *
     * @param fileContent the content of the file to search in.
     * @param keyword     the key word to find.
     */
    public static void search(String fileContent, String keyword) {
        int lastIndex = 0;
        int count = 0;
        while (lastIndex != -1) {
            lastIndex = fileContent.indexOf(keyword, lastIndex);

            if (lastIndex != -1) {
                count++;
                lastIndex += keyword.length();
            }
        }
        System.out.println(String.format("Found %d times %s", count, keyword));
        if (results.containsKey(keyword)) {
            int c = results.get(keyword);
            c = c + count;
            results.put(keyword, c);
        } else {
            results.put(keyword, count);
        }
    }

    /**
     * Search for the given keyowrds in all logs contained in the bucket that contain the fileNameKeyword.
     *
     * @param bucketName      the name of the bucket to search in.
     * @param fileNameKeyWord keyword for the logfiles to retreive.
     * @param keywords        keywords to search in the logs
     * @return a map containing the number of times, the keywords occurred in the given bucket
     */
    public static ConcurrentHashMap<String, Integer> searchInAll(String bucketName, String fileNameKeyWord,
                                                                 List<String> keywords) {
        results = new ConcurrentHashMap<>();
        List<String> fileNames = LogOperations.getAllLogs(bucketName, fileNameKeyWord);
        for (String fileName : fileNames) {
            S3FileHandler.download(bucketName, fileName);
            File file = new File(fileName);
            try {
                String fileContent = FileUtils.readFileToString(file);
                new Thread() {

                    @Override
                    public void run() {
                        for (String keyword : keywords) {
                            search(fileContent, keyword);
                        }
                    }

                }.start();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            file.delete();
        }
        System.out.println(String.format("Number of results =  %s", results.size()));
        print(results);
        return results;
    }

    private static void print(ConcurrentHashMap<String, Integer> orrences) {
        orrences.forEach((key, times) -> System.out.println(String.format("In total, found %s %s times", key, times)));
    }
}
