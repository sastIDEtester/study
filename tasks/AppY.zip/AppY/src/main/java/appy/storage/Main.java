package appy.storage;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import appy.utils.LogUtils;

/**
 * Commandline interface for the s3 tools.
 */
public class Main {
    private static final String CREATE_USAGE = "create <bucketName>";
    private static final String DOWNLOAD_USAGE = "download <bucketName> <fileName>";
    private static final String SEARCH_FILE_USAGE = "searchFile <bucketName> <fileNameKeyWorkd> <outputFile>";
    private static final String SEARCH_KEYWORDS_USAGE = "searchKeywords <bucketName> <fileNameKeyWorkd> <keyword1> <keyword2> ...";
    private static final String USAGE = String.join("\n\n", "", "Usage:", CREATE_USAGE, DOWNLOAD_USAGE,
                                                    SEARCH_FILE_USAGE, SEARCH_KEYWORDS_USAGE);

    public static void main(String[] args) throws InterruptedException {
        if (args.length < 1) {
            System.err.println(USAGE);
            System.exit(1);
        }
        String command = args[0];
        switch (command) {
            case "create":
                if (args.length == 2)
                    CreateBucket.createBucket(args[1]);
                else
                    System.err.println(USAGE);
                break;
            case "download":
                if (args.length == 3)
                    S3FileHandler.download(args[1], args[2]);
                else
                    System.err.println(USAGE);
                break;
            case "searchFile":
                if (args.length == 4) {
                    List<String> logs = LogOperations.getAllLogs(args[1], args[2]);
                    File file = new File(args[3]);
                    LogUtils.save(file, logs);
                } else
                    System.err.println(USAGE);
                break;
            case "searchKeywords":
                if (args.length > 3) {
                    List<String> keywords = new ArrayList<>();
                    for (int i = 3; i < args.length; i++) {
                        keywords.add(args[i]);
                    }
                    SearchInLogs.searchInAll(args[1], args[2], keywords);
                } else
                    System.err.println(USAGE);
                break;
            default:
                System.exit(1);
        }
    }
}
