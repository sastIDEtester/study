package appy.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class LogUtils {

    /**
     * Saves the list of logs to a file.
     *
     * @param file
     * @param logs
     */
    public static void save(File file, List<String> logs) {
        BufferedWriter writer;
        try {
            if (logs.isEmpty()) {
                return;
            } else {
                writer = new BufferedWriter(new FileWriter(file));
                logs.forEach(s -> {
                    try {
                        writer.append(s);
                        writer.newLine();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });

            }
            writer.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
