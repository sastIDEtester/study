package appy.utils;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.Region;

public class ClientUtils {
    public static AmazonS3 getS3() {
        return AmazonS3ClientBuilder.standard().withRegion(Region.US_West_2.toString()).build();
    }
}
