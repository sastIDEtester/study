package appx.serialize;

import java.util.List;
import java.util.Map;

import appx.db.data.Musician;
import appx.db.data.Musician.MusicianBuilder;
import com.google.common.collect.ImmutableList;

import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.QueryResult;

/**
 * Helper class to convert a query result into a Musician Object.
 */
public class QueryResultConverter {

    /**
     * Converts the given query result into a musician. The fields Name, Born, Language and City will be deserialized to the object.
     * If field are missing they will be null in the result. Additional information contained in the response will be ignored.
     *
     * @param ddbResponse the Database query result.
     * @param attrName    field name that should be filtered out of the result because of data protection.
     * @return the musician object
     */
    public static Musician convert(final QueryResult ddbResponse, final String attrName) {
        List<Map<String, AttributeValue>> items = !ddbResponse.getItems().isEmpty() ? ddbResponse.getItems()
                                                                                    : ImmutableList.of();
        final MusicianBuilder resultBuilder = Musician.builder();
        if (!items.isEmpty()) {
            Map<String, AttributeValue> attList = items.get(0);

            attList.forEach((key, value) -> {
                if (!key.equals(attrName)) {
                    switch (key) {
                        case "Name":
                            resultBuilder.name(value.getS());
                            break;
                        case "Born":
                            resultBuilder.born(value.getS());
                            break;
                        case "Language":
                            resultBuilder.language(value.getS());
                            break;
                        case "City":
                            resultBuilder.city(value.getS());
                            break;
                        default:
                            break;
                    }
                }

            });
        }

        return resultBuilder.build();
    }


}
