package appx.serialize;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.google.common.collect.ImmutableList;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.QueryRequest;
import software.amazon.awssdk.services.dynamodb.model.QueryResponse;

/**
 * Simple class to query information of a musician and output.
 */
public class SimpleQuery {

    /**
     * Print the values for key {@code attrName} contained in the query response into the console.
     *
     * @param ddbResponse the query result.
     * @param attrName    the attribute name to print
     */
    public static void print(final QueryResponse ddbResponse, final String attrName) {
        final List<Map<String, AttributeValue>> items = ddbResponse.hasItems() ? ddbResponse.items()
                                                                               : ImmutableList.of();
        final List<String> values = items.stream().map(attributeValueMap -> attributeValueMap.get(attrName).s())
                                         .collect(Collectors.toList());
        for (String s : values) {
            System.out.print(s);
        }
    }

    public static void main(String... args) {
        DynamoDbClient client = DynamoDbClient.create();
        String tableName = args[0];
        String name = args[1];
        String attrName = args[2];
        String partition_alias = "#a";
        String partition_key_name = "Name";
        HashMap<String, String> attrNameAlias = new HashMap<String, String>();
        attrNameAlias.put(partition_alias, partition_key_name);
        HashMap<String, AttributeValue> attrValues = new HashMap<String, AttributeValue>();
        attrValues.put(":" + partition_key_name, AttributeValue.builder().s(name).build());
        QueryRequest request =
            QueryRequest.builder().tableName(tableName).keyConditionExpression(
                partition_alias + " = :" + partition_key_name).expressionAttributeNames(attrNameAlias)
                        .expressionAttributeValues(attrValues).build();
        QueryResponse response = client.query(request);
        System.out.println(String.format("%s for %s: ", attrName, name));
        print(response, attrName);
    }
}
