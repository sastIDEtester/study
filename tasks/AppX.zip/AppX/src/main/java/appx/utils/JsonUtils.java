package appx.utils;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import appx.db.data.Musician;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JsonUtils {
    private static ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Write the queried musicians given by the list of musicians into the file specified by the filePath in json format.
     *
     * @param musicians the queried musicians
     * @param filePath  the path to write to
     */
    public static void writeQueriedMusicians(List<Musician> musicians, Path filePath) {

        if (musicians.size() > 0) {
            log.info("-------------------------------------------------------");
            log.info(String.format("Number of musicians that are queried =  %s", musicians.size()));
            for (Musician m : musicians) {
                log.info(String.format("\"%s\"", m.getName()));
            }

            try {
                if (Files.exists(filePath)) {
                    log.info(String.format("A File already exists at  %s.Overwriting results to this File",
                                           filePath.toString()));
                }
                objectMapper.writeValue(filePath.toFile(), musicians);
                log.info(String.format("The results are saved here  %s", filePath.toString()));
                log.info("-------------------------------------------------------");
            } catch (Exception e) {
                throw new RuntimeException(
                    String.format("Unable to write property map to file: %s", filePath.toString()), e);
            }
        }
    }

    /**
     * Write all musicians given by the list of musicians into the file specified by the filePath in json format.
     *
     * @param musicians all musicians
     * @param filePath  the path to write to
     */
    public static void writeAllMusicians(List<Musician> musicians, Path filePath) {

        if (musicians.size() > 0) {

            log.info("-------------------------------------------------------");
            log.info(String.format("Number of all musicians=  %d",
                                   musicians.size()));
            for (Musician m : musicians) {
                log.info(String.format("\"%s\"", m.getName()));
            }
            try {
                if (Files.exists(filePath)) {
                    log.info(String.format("A File already exists at  %s.Overwriting results to this File",
                                           filePath.toString()));
                }
                objectMapper.writeValue(filePath.toFile(), musicians);
                log.info(String.format("The results are saved here  %s", filePath.toString()));
                log.info("-------------------------------------------------------");
            } catch (Exception e) {
                throw new RuntimeException(
                    String.format("Unable to write property map to file: %s", filePath.toString()), e);
            }
        }
    }

}
