package appx.utils;


import java.util.Map;
import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.google.common.util.concurrent.ThreadFactoryBuilder;

import com.amazonaws.services.dynamodbv2.model.AmazonDynamoDBException;

/**
 * Helper class providing functions to schedule tasks in an executor service.
 */
public class ThreadRunner {
    private ExecutorService exec;
    private ExecutorCompletionService<Boolean> runner;
    private Map<String, AmazonDynamoDBException> currentExceptions;

    /**
     * Creates a new Threadrunner
     */
    public ThreadRunner() {
        exec = Executors.newFixedThreadPool(1,
                                            new ThreadFactoryBuilder().setNameFormat("thread-%d").setDaemon(true)
                                                                      .build());
        this.runner = new ExecutorCompletionService<Boolean>(exec);
        this.currentExceptions = new ConcurrentHashMap<>();
    }

    /**
     * Schedules the given task on the executor service.
     *
     * @param task the task.
     * @return a Future representing pending completion of the task
     */
    public Future<Boolean> compute(Callable<Boolean> task) {
        return runner.submit(task);
    }

    /**
     * Shuts down the executor service.
     */
    public void shutDown() {
        exec.shutdown();
    }

    /**
     * Checks the result of the next submitted task.
     *
     * @return an {@link Optional} containing the result, or an empty optional if there was no more task.
     */
    Optional<Boolean> checkResult() {
        try {
            Future<Boolean> result = runner.poll();
            if (result != null) {
                return Optional.of(result.get());
            }
        } catch (Throwable e) {
            Throwable cause = e.getCause();
            if (cause instanceof AmazonDynamoDBException) {
                AmazonDynamoDBException adException = (AmazonDynamoDBException) cause;
                currentExceptions.put(adException.getErrorCode(), adException);
            }
        }
        return Optional.empty();
    }

    /**
     * Fetches the exception for the given errorcode id.
     *
     * @param adID the errorcode id
     * @return an {@link Optional} with the exception or an empty optional if there is no exception.
     */
    public Optional<AmazonDynamoDBException> fetchException(String adID) {
        checkResult();
        if (currentExceptions.containsKey(adID)) {
            return Optional.of(currentExceptions.remove(adID));
        }
        return Optional.empty();
    }
}
