package appx.db;

import appx.db.credentials.ClientUtils;
import lombok.extern.slf4j.Slf4j;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.dynamodbv2.model.AttributeDefinition;
import com.amazonaws.services.dynamodbv2.model.CreateTableRequest;
import com.amazonaws.services.dynamodbv2.model.CreateTableResult;
import com.amazonaws.services.dynamodbv2.model.KeySchemaElement;
import com.amazonaws.services.dynamodbv2.model.KeyType;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.model.ScalarAttributeType;


@Slf4j
public class CreateTable {

    public static final String COMMAND = "CreateTable";
    public static final String USAGE = String.join("\n", COMMAND + " <table>", "  Where:",
                                                   "    table - the table to create.", "  Example:",
                                                   "    " + COMMAND + "HelloTable");

    /**
     * Create a table with the given name.
     */
    protected static void createTable(String table_name) {
        log.info("Creating table \"%s\" with a simple primary key: \"Name\".\n", table_name);
        try {
            CreateTableRequest request = new CreateTableRequest()
                .withAttributeDefinitions(new AttributeDefinition("Name", ScalarAttributeType.S))
                .withKeySchema(new KeySchemaElement("Name", KeyType.HASH))
                .withProvisionedThroughput(new ProvisionedThroughput(10L, 10L))
                .withTableName(table_name);
            CreateTableResult result = ClientUtils.getDBB().createTable(request);
            log.info("Created " + result.getTableDescription().getTableName());
        } catch (AmazonServiceException e) {
            log.error(e.getErrorMessage());
            throw new IllegalArgumentException();
        }
        log.info("Done!");
    }
}
