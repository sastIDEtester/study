package appx.db;

import java.util.Arrays;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Main {
    private static final String CREATE_TABLE_USAGE = CreateTable.USAGE;
    private static final String ADD_NEW_MUSICIAN_USAGE = MusicianAccess.USAGE_ADD;
    private static final String QUERY_MUSICIAN_USAGE = MusicianAccess.USAGE_QUERY;
    private static final String EXPORT_MUSICIAN_USAGE = MusicianAccess.USAGE_EXPORT;

    private static final String USAGE = String.join("\n\n", "", "Usage:", CREATE_TABLE_USAGE, ADD_NEW_MUSICIAN_USAGE,
                                                    QUERY_MUSICIAN_USAGE, EXPORT_MUSICIAN_USAGE);

    public static void main(String[] args) throws InterruptedException {
        if (args.length < 1) {
            log.error(USAGE);
            System.exit(1);
        }

        String command = args[0];
        switch (command) {
            case CreateTable.COMMAND:
                createTable(args);
                break;
            case MusicianAccess.COMMAND_ADD:
                addNewMusician(args);
                break;
            case MusicianAccess.COMMMAND_QUERY:
                queryMusician(args);
                break;
            case MusicianAccess.COMMMAND_EXPORT:
                exportMusician(args);
                break;
            default:
                log.error(USAGE);
                System.exit(1);
        }
    }

    private static void createTable(String[] args) {
        if (args.length < 2) {
            log.error("\nUsage:\n" + CREATE_TABLE_USAGE);
            System.exit(1);
        }
        String tableName = args[1];
        CreateTable.createTable(tableName);
    }

    private static void addNewMusician(String[] args) throws InterruptedException {
        if (args.length < 3) {
            log.error("\nUsage:\n" + ADD_NEW_MUSICIAN_USAGE);
            System.exit(1);
        }
        String tableName = args[1];
        TableStatusUtils.waitForTableActive(tableName, 20);
        String name = args[2];
        String[] extraArgs = Arrays.copyOfRange(args, 3, args.length);
        MusicianAccess.addMusician(tableName, name, extraArgs);
    }

    private static void queryMusician(String[] args) throws InterruptedException {
        if (args.length < 3) {
            log.error("\nUsage:\n" + ADD_NEW_MUSICIAN_USAGE);
            System.exit(1);
        }
        String tableName = args[1];
        TableStatusUtils.waitForTableActive(tableName, 20);
        String name = args[2];
        log.info(MusicianAccess.queryMusician(tableName, name).toString());
    }

    private static void exportMusician(String[] args) throws InterruptedException {
        if (args.length < 4) {
            log.error("\nUsage:\n" + EXPORT_MUSICIAN_USAGE);
            System.exit(1);
        }
        String tableName = args[1];
        TableStatusUtils.waitForTableActive(tableName, 20);
        String name = args[2];
        String fileName = args[3];
        MusicianAccess.musicianToJsonFile(tableName, name, fileName);
        log.info(MusicianAccess.queryMusician(tableName, name).toString());
    }
}
