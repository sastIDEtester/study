package appx.db.credentials;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;


public class ClientUtils {

    public static AmazonDynamoDB getDBB() {
        return AmazonDynamoDBClientBuilder.standard().withRegion(Regions.US_WEST_2).build();
    }
}
