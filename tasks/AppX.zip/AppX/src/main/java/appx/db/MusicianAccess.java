package appx.db;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;

import appx.db.credentials.ClientUtils;
import appx.db.data.Musician;
import appx.serialize.QueryResultConverter;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.dynamodbv2.model.AmazonDynamoDBException;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.QueryRequest;
import com.amazonaws.services.dynamodbv2.model.QueryResult;
import com.amazonaws.services.dynamodbv2.model.ResourceNotFoundException;

@Slf4j
/**
 * Class to provide access functions to the Musician Table.
 */
public class MusicianAccess {

    public static final String COMMAND_ADD = "AddMusician";
    public static final String USAGE_ADD = COMMAND_ADD + " <table> <name> [field=value ...]\n" + "  Where:\n"
                                           + "    table    - the table to put the item in.\n"
                                           + "    name     - a name to add to the table. If the name already\n"
                                           + "               exists, its entry will be updated.\n"
                                           + "   Additional fields can be added by appending them to the end of the\n" + "   input.\n" + "  Example:\n"
                                           + "    " + COMMAND_ADD + " Musicians Pau Language=ca Born=1876\n";
    public static final String COMMMAND_QUERY = "QueryMusician";
    public static final String USAGE_QUERY = COMMMAND_QUERY + " <table> <name>\n" + "  Where:\n"
                                             + "    table    - the table to query\n" + "    name     - the musicians name to query\n" + "  Example:\n"
                                             + "    " + COMMMAND_QUERY + " Musicians Pau";
    public static final String COMMMAND_EXPORT = "ExportMusician";
    public static final String USAGE_EXPORT = COMMMAND_EXPORT + " <table> <name> <fileName>\n"
                                              + "  Where:\n"
                                              + "    table    - the table to query\n"
                                              + "    name     - the musicians name to query\n"
                                              + "    fileName - the filename that the export is written to\n"
                                              + "  Example:\n"
                                              + "    " + COMMMAND_EXPORT + " Musicians Pau pau.json";

    /**
     * Adds a musician with given name {@code name} to the specified table.
     *
     * @param tableName the DynamoDb table name
     * @param name      the name of the musician to be created
     * @param extraArgs (optional) an array of keyValue pairs formatted as <pre>&lt;key&gt;=&lt;value&gt;</pre> to be added to the musician.
     *                  Keys will be saved as a columns in the table.
     */
    protected static void addMusician(String tableName, String name, String... extraArgs) {
        ArrayList<String[]> extra_fields = new ArrayList<String[]>();
        // any additional args (fields to add to database)?
        for (int x = 0; x < extraArgs.length; x++) {
            String[] fields = extraArgs[x].split("=", 2);
            if (fields.length == 2) {
                extra_fields.add(fields);
            } else {
                log.error(String.format("Invalid argument: %s\n", extraArgs[x]));
                log.error("\nUsage:\n" + USAGE_ADD);
                throw new IllegalArgumentException();
            }
        }

        log.info(String.format("Adding %s to %s", name, tableName));
        if (extra_fields.size() > 0) {
            log.info("Additional fields:");
            for (String[] field : extra_fields) {
                log.info(String.format("  %s: %s\n", field[0], field[1]));
            }
        }

        HashMap<String, AttributeValue> item_values = new HashMap<String, AttributeValue>();

        item_values.put("Name", new AttributeValue(name));

        for (String[] field : extra_fields) {
            item_values.put(field[0], new AttributeValue(field[1]));
        }

        try {
            ClientUtils.getDBB().putItem(tableName, item_values);
        } catch (ResourceNotFoundException e) {
            log.error(String.format("Error: The table \"%s\" can't be found.\n", tableName));
            log.error("Be sure that it exists and that you've typed its name correctly!");
            throw new IllegalArgumentException();
        } catch (AmazonServiceException e) {
            log.error(e.getMessage());
            throw new IllegalArgumentException();
        }
        log.info("Done!");

    }

    /**
     * Query the musician with name {@code name} from the table specified by the table name.
     *
     * @param tableName the name of the table to query
     * @param name      the name of the musician to be queried
     * @return the Musician or an empty Musician object if the musician was not found.
     */
    public static Musician queryMusician(String tableName, String name) {
        String partition_alias = "#a";
        String partition_key_name = "Name";
        // set up an alias for the partition key name in case it's a reserved word
        HashMap<String, String> attrNameAlias = new HashMap<String, String>();
        attrNameAlias.put(partition_alias, partition_key_name);
        // set up mapping of the partition name with the value
        HashMap<String, AttributeValue> attrValues = new HashMap<String, AttributeValue>();
        attrValues.put(":" + partition_key_name, new AttributeValue().withS(name));
        QueryRequest queryReq = new QueryRequest().withTableName(tableName)
                                                  .withKeyConditionExpression(
                                                      partition_alias + " = :" + partition_key_name)
                                                  .withExpressionAttributeNames(attrNameAlias)
                                                  .withExpressionAttributeValues(attrValues);
        log.info(queryReq.toString());
        try {
            QueryResult response = ClientUtils.getDBB().query(queryReq);
            return QueryResultConverter.convert(response, "Born");
        } catch (AmazonDynamoDBException e) {
            log.error(e.getErrorMessage());
            throw new RuntimeException();
        }
    }

    /**
     * Queries a musician and writes the result to a file with the given name in json format.
     *
     * @param tableName the name of the table to query
     * @param name      the name of the musician to query
     * @param fileName  the name of the file to be created
     */
    public static void musicianToJsonFile(String tableName, String name, String fileName) {
        int waitSeconds = 20;
        try {
            FileOutputStream fileOut = new FileOutputStream(fileName);
            TableStatusUtils.waitForTableActive(tableName, waitSeconds);
            String partition_alias = "#a";
            String partition_key_name = "Name";
            // set up an alias for the partition key name in case it's a reserved word
            HashMap<String, String> attrNameAlias = new HashMap<String, String>();
            attrNameAlias.put(partition_alias, partition_key_name);

            // set up mapping of the partition name with the value
            HashMap<String, AttributeValue> attrValues = new HashMap<String, AttributeValue>();
            attrValues.put(":" + partition_key_name, new AttributeValue().withS(name));
            QueryRequest queryReq = new QueryRequest().withTableName(tableName)
                                                      .withKeyConditionExpression(
                                                          partition_alias + " = :" + partition_key_name)
                                                      .withExpressionAttributeNames(attrNameAlias)
                                                      .withExpressionAttributeValues(attrValues);
            System.out.println(queryReq.toString());
            try {
                QueryResult response = ClientUtils.getDBB().query(queryReq);
                Musician m = QueryResultConverter.convert(response, "Born");
                write(fileOut, m);

                System.out.println(response.getCount());
            } catch (AmazonDynamoDBException e) {
                log.error(e.getErrorMessage());
                throw new RuntimeException();
            } catch (IOException e) {
                log.error(e.getMessage(), e);
            }
        } catch (InterruptedException e) {
            throw new RuntimeException("table not active");
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Write the musician to the outputstream as a json String.
     * The output stream will be closed after the operation finishes.
     *
     * @param out the {@link OutputStream} to write to
     * @param m   the Musician to write to the stream
     * @throws IOException
     */
    public static void write(OutputStream out, Musician m) throws IOException {
        String prettyString = new ObjectMapper().convertValue(m, JsonNode.class).toPrettyString();
        OutputStreamWriter osw = new OutputStreamWriter(out);
        osw.append(prettyString);
        osw.flush();
        osw.close();
    }

}
