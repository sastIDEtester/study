package appx.db;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;

import appx.db.data.Musician;
import org.junit.Test;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

public class MusicianAccessTest {

    /**
     *
     */
    private static final String MUSICIAN_TABLE = "MusicianTable";

    @Test
    public void testAddMusician() {
        String name = UUID.randomUUID().toString();
        String born = "1234";
        String city = "Test";
        String language = "ee";
        MusicianAccess.addMusician(MUSICIAN_TABLE, name, "Born=" + born, "City=" + city, "Language=" + language);
        Musician retrieved = MusicianAccess.queryMusician(MUSICIAN_TABLE, name);
        assertEquals(name, retrieved.getName());
        assertEquals(null, retrieved.getBorn());
        assertEquals("Test", retrieved.getCity());
        assertEquals("ee", retrieved.getLanguage());

        name = UUID.randomUUID().toString();
        MusicianAccess.addMusician(MUSICIAN_TABLE, name);
        retrieved = MusicianAccess.queryMusician(MUSICIAN_TABLE, name);
        assertEquals(name, retrieved.getName());
        assertEquals(null, retrieved.getBorn());
        assertEquals(null, retrieved.getCity());
        assertEquals(null, retrieved.getLanguage());
    }

    @Test
    public void testQueryMusician() {

        Musician m1 = MusicianAccess.queryMusician(MUSICIAN_TABLE, "Karen C Pritt");
        assertEquals("Karen C Pritt", m1.getName());
        assertEquals(null, m1.getBorn());
        assertEquals("Berlin", m1.getCity());
        assertEquals("ca", m1.getLanguage());

        Musician m2 = MusicianAccess.queryMusician(MUSICIAN_TABLE, "nonExistent");
        assertEquals(null, m2.getName());
        assertEquals(null, m2.getBorn());
        assertEquals(null, m2.getCity());
        assertEquals(null, m2.getLanguage());

    }

    @Test
    public void testExportMusician() throws IOException {
        // cleanup before
        Files.deleteIfExists(Paths.get("karen.json"));
        Files.deleteIfExists(Paths.get("nonExistent.json"));

        MusicianAccess.musicianToJsonFile(MUSICIAN_TABLE, "Karen C Pritt", "karen.json");
        List<String> karenJson = Files.readAllLines(Paths.get("karen.json"));
        assertArrayEquals(new Object[]{"{", "  \"name\" : \"Karen C Pritt\",", "  \"born\" : null,",
                                       "  \"language\" : \"ca\",", "  \"city\" : \"Berlin\"", "}"},
                          karenJson.toArray());

        MusicianAccess.musicianToJsonFile(MUSICIAN_TABLE, "nonExistent", "nonExistent.json");
        List<String> nonExistentJson = Files.readAllLines(Paths.get("nonExistent.json"));
        assertArrayEquals(new Object[]{"{", "  \"name\" : null,", "  \"born\" : null,", "  \"language\" : null,",
                                       "  \"city\" : null", "}"}, nonExistentJson.toArray());

    }
}
