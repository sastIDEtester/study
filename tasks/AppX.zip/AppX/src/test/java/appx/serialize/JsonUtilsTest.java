package appx.serialize;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;

import appx.db.data.Musician;
import appx.utils.JsonUtils;
import org.junit.Test;
import static org.junit.Assert.assertTrue;

public class JsonUtilsTest {

    @Test
    public void testWriteQueriedMusicians() {
        Musician musician = Musician.builder().name("Tom").city("Toykio").build();
        Path p = Paths.get("test.json");
        if (p.toFile().exists())
            p.toFile().delete();
        JsonUtils.writeQueriedMusicians(Collections.singletonList(musician), p);
        assertTrue(p.toFile().exists());
    }
}
