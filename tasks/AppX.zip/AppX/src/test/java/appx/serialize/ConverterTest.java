package appx.serialize;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import appx.db.data.Musician;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.QueryResult;

public class ConverterTest {

    @Test
    public void testConvert() {
        QueryResult res = new QueryResult();
        Map<String, AttributeValue> values = new HashMap<>();
        values.put("Name", new AttributeValue().withS("TestName"));
        values.put("Born", new AttributeValue().withS("1875"));
        values.put("City", new AttributeValue().withS("New York"));
        values.put("Language", new AttributeValue().withS("de"));
        res.setItems(Arrays.asList(values));
        Musician m = QueryResultConverter.convert(res, "none");
        assertEquals(Musician.builder().name("TestName").born("1875").city("New York").language("de").build(), m);

        m = QueryResultConverter.convert(res, "Born");
        assertEquals(Musician.builder().name("TestName").city("New York").language("de").build(), m);

        m = QueryResultConverter.convert(res, "Name");
        assertEquals(Musician.builder().born("1875").city("New York").language("de").build(), m);

        m = QueryResultConverter.convert(res, "City");
        assertEquals(Musician.builder().name("TestName").born("1875").language("de").build(), m);

        m = QueryResultConverter.convert(res, "Language");
        assertEquals(Musician.builder().name("TestName").born("1875").city("New York").build(), m);

        res = new QueryResult();
        values = new HashMap<>();
        values.put("Name", new AttributeValue().withS("TestName"));
        res.setItems(Arrays.asList(values));
        m = QueryResultConverter.convert(res, "none");
        assertEquals(Musician.builder().name("TestName").build(), m);
    }
}
